$aa[1]="A";$aa[2]="C";$aa[3]="D";$aa[4]="E";$aa[5]="F";$aa[6]="G";$aa[7]="H";$aa[8]="I";$aa[9]="K";$aa[10]="L";$aa[11]="M";$aa[12]="N";$aa[13]="P";$aa[14]="Q";$aa[15]="R";$aa[16]="S";$aa[17]="T";$aa[18]="V";$aa[19]="W";$aa[20]="Y";

@seq=`cat input.seq`;chomp @seq;
$seq1="";
`rm resultall.txt result200.txt`;
foreach $seq(@seq)
{
	
	if($seq=~ />/)
	{
		@tt=split(/\|/,$seq);chomp @tt;
		$head=$tt[1];
		$head=~ s/>//g;
		if($head eq ""){$head=$seq;$head=~ s/>//g;}
	}
	else
	{
		$seq1=$seq1.$seq;
	}
}
$seq1=~ s/\s+//g;
$len=length($seq1);
$fno=0;
open(DATA,">data.seq");
print DATA">SEQ\n$seq1\n";
close DATA;
#`/home/GANESAP/software/sable_distr/run.sable`;

`./run.sable`;
#`cp sable_out/$head.sable OUT_SABLE_RES`;
@psa=`perl sable-parse.pl`;chomp @psa;
#`mv OUT_SABLE_RES sable_out1/$head.sable`;
#`mv OUT_SABLE/align.out sable_out1/$head.out`;
#`rm -rf OUT_SABLE OUT_SABLE_graph `;
#`rm -rf OUT_SABLE OUT_SABLE_graph OUT_SABLE_RES`;

open(TEST,">test.csv");
for($i=0;$i<=$len-3;$i++)
{
	$str=substr($seq1,$i,3);
	if($str=~ /N.[ST]/)
	{
		#if($str!~ /NP/)
		#{
			$Npos=$i+1;
			#$sequon=substr($seq1,$Npos-1,3);
			if($Npos<=5)
			{
				$Lstart=1;$strlen=$Npos-$Lstart;
				$left=substr($seq1,$Lstart-1,$strlen);
			}
			else{$Lstart=$Npos-5;$left=substr($seq1,$Lstart-1,5);}
			$Rstart=$Npos+3;
			$right=substr($seq1,$Rstart-1,5);
			$len1=length($left);$len2=length($right);
			$start13=$Lstart;$end13=$Rstart+5-1;
			if(($len1==5)&&($len2==5))
			{
				$fno++;
				$sequon[$fno]=substr($seq1,$Npos-1,3);
				$nposition[$fno]=$Npos;
				$left5[$fno]="$left";
				$right5[$fno]="$right";
				#print "$Npos $Lstart $Rstart: $start13 $end13: $left $sequon $right\n";
				open(XX,">blastinput.seq");
				if($len<=70)
				{
					print XX">SEQ\_$Npos $Npos 1 $len\n$seq1\n";
				}
				else
				{	
					if($Npos<=25){$st=1;$end=$Npos+50;}
					elsif($Npos>=$len-25){$st=$Npos-50;$end=$len;}
					else{$st=$Npos-25;$end=$Npos+25;}
					$strlen=$end-$st+1;
					$str=substr($seq1,$st-1,$strlen);
					$qst=$st;$qend=$end;
					print XX">SEQ\_$Npos $Npos $qst $qend\n$str\n";
					#print ">SEQ\_$Npos $Npos $qst $qend\n$str\n";
					$seqcode="SEQ"."_$Npos";
				}
				close XX;
				@out=`perl runblast.pl`;chomp @out;
				undef @ares;
				foreach $out(@out)
				{
					@arr1=split(/\s+/,$out);chomp @arr1;
					$st2=$qst-1;$end2=$arr1[1];
					@res1=split(//,$arr1[4]);chomp @res1;
					@res2=split(//,$arr1[5]);chomp @res2;
					$pos=0;
					for($m=0;$m<=$#res1;$m++)
					{
						if($res1[$m] ne "-")
						{
							$st2++;
							if(($st2>=$start13)&&($st2<=$end13))
							{
								$pos++;
								$ares[$pos]=$ares[$pos]."$res2[$m]";
							}
						}
					}
				}
				#for($m=1;$m<=13;$m++){print "$m $ares[$m]\n";}
				##############Nx[ST]postion
				print TEST"$fno,";
				$pro=substr($ares[6],0,1);
				$ser=substr($ares[8],0,1);
				if($pro eq "P"){print TEST"1,";}else{print TEST"0,";}
				if($ser eq "S"){print TEST"1,";}else{print TEST"0,";}
				if($ser eq "T"){print TEST"1,";}else{print TEST"0,";}
				for($j=1;$j<=13;$j++)
				{
					$num=length($ares[$j]);
					@rs=split(//,$ares[$j]);chomp @rs;
					undef @sum;
					for($k=1;$k<=20;$k++)
					{
						foreach $rs(@rs)
						{
							if($rs eq $aa[$k]){$sum[$k]++;}
						}
					}
					for($k=1;$k<=20;$k++)
					{
						if($sum[$k]<=0){$per=0;}
						else{$per=(100*$sum[$k])/$num;}
						$per=sprintf "%0.2f",$per;
						printf TEST"$per,";
					}
				}
				######Psa and sst
				$n3=$end13-$start13+1;
				#@psa=`grep "$code[0]" SABLE-Result.txt`;chomp @psa;
				#@psa=`perl sable-parse.pl`;chomp @psa;
				$sst=substr($psa[0],$start13-1,$n3);
				$asa=substr($psa[1],$start13-1,$n3);
				@t=split(//,$sst);chomp @t;
				foreach $t(@t)
				{
					if($t eq "H"){print TEST"1,"}else{print TEST"0,";}
					if($t eq "E"){print TEST"1,"}else{print TEST"0,";}
					if($t eq "C"){print TEST"1,"}else{print TEST"0,";}
				}
				@t=split(//,$asa);chomp @t;
				$t1="";
				foreach $t(@t){$t1=$t1."$t,";}
				$t1=~ s/,$//g;
				print TEST"$t1\n";
			}
		#}
	}
}
close TEST;
@f200=`cat features200-list.txt`;chomp @f200;
@ft=`cat test.csv`;chomp @ft;
$fno=0;
open(TEST1,">test200.csv");
foreach $ft(@ft)
{
	@f=split(/,/,$ft);chomp @ft;
	$fno++;
	#print "$fno,";
	$ft1="$fno,";
	foreach $f200(@f200)
	{
		$ft1=$ft1."$f[$f200],";
		#print "$f[$f200],";
	}
	$ft1=~ s/,$//g;
	print TEST1"$ft1\n";
}
close TEST1;
`/usr/bin/R --vanilla < randomforest.r`;
`/usr/bin/R  --vanilla < randomforest200.r`;
@pred=`cat resultall.txt`;chomp @pred;
@pred200=`cat result200.txt`;chomp @pred200;
for($k=1;$k<=$fno;$k++)
{
	if($pred[$k-1]==1){$type1="Ngly";}
	else{$type1="NonGly";}
	if($pred200[$k-1]==1){$type2="Ngly";}
	else{$type2="NonGly";}
	printf "%-7s  %-3s   %-5s  %-5s   %-10s  %-10s $head\n",$nposition[$k],$sequon[$k],$left5[$k],$right5[$k],$type1,$type2; 
}
