# Please install R-stastical Package and randomForest package on your system; you will get them on CRAN site.  
# Input format:.csv (comma seperated) files.
# The output will be the error rate , confusion matrix,Prediction Y labels for test dataset 
# Prediction_results.txt will store predicted y lables for test dataset
# Please keep all your input files in one folder


# Removes all previous matrices and variables from the R-System memory.
rm(list=ls())

# store the current directory in the variable 
initial.dir<-getwd()

# change to the new directory where the data file is stored
#setwd("/Users/kkandaswamy/Desktop/dataset")

# load the necessary libraries 						
library(randomForest)
  
	    
testPP<-numeric()

# load the top200 features model
load ('/home/kandaswamy/pugal_Nglycos/program/modelfile_final_allfea.rda')
# load the dataset
QdataTest <- read.csv('test.csv',header = FALSE)
			    
 

QdataTestX <- subset(QdataTest,select=-V1)
QdataTestY<-as.factor(QdataTest$V1)



# Predicted Y labels for test dataset:
m<-predict(mdl,QdataTestX)

print(m)
  
# CONFUSION MATRIX.for Testing dataset
# Confusion Matrix will be as .. 
# TP FN
# FP TN

# and will be accesed as..
# t[1] t[3]
# t[2] t[4]


# Predicted Y labels for test dataset will store in file predicted_results.txt

outputFile <- "resultall.txt"
write.table(m ,file=outputFile,quote=FALSE,row.names=F,col.names=F,sep="\t")

t<-table(QdataTestY,m)
print(t)

